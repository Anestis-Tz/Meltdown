package game.data;

/*
 * Here you can initialize the objects (rooms, treasures etc.) of the game
 */
import gameobjects.Actor;
import gameobjects.ContainerThing;
import gameobjects.GameThing;
import gameobjects.GenericThing;
import gameobjects.LockableThing;
import gameobjects.Room;
import gameobjects.Thing;
import globals.Dir;
import globals.Mass;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class GameData implements java.io.Serializable {

    // NOTE: 
    // map: 
    // This is not needed for the functioning of this game
    // since the player (an Actor object) can move from Room to Room
    // autonomously. However, a sequential list of all Rooms is useful
    // for debugging. 
    // 
    // things: 
    // The HashMap of things lets you find a thing (by its key) 
    // when you need to verify its state (open, closed, etc.) Again this
    // is not needed for the functioning of the game but it's useful
    // when debugging.
    public static ArrayList<Room> map; // the map - an ArrayList of Rooms    
    public static HashMap<String, Thing> things; // treasures
    public static Actor player;  // player - provides 'first person perspective'  
    private static String introtext = ""; // intro description

    public static void initGame() {

        // To construct a new Game, you should create and initialze objects 
        // in the order show. That's because some objects require other
        // objects - for example, all Ro9oms must be created before they
        // are initialized because Rooms refernce other Rooms for their 'exits'
        // --- construct a new adventure ---
        // 1) --- Create rooms ---
        Room rangerStationCharlie = new Room("Ranger Station Charlie");
        Room mojaveDesert = new Room("Mojave Desert");
        Room goodsprings = new Room("Goodsprings");
        Room mojaveOutpost = new Room("Mojave Outpost");
        Room primm = new Room("Primm");
        Room redRockCanyon = new Room("Red Rock Kanyon");
        Room fiends = new Room("Fiends");
        Room novac = new Room("Novac");
        Room boulderBeach = new Room("Boulder Beach");
        Room caesarsLegion = new Room("Caesars Legion");
        Room campMcCarran = new Room("Camp McCarran");
        Room newVegasEntrance = new Room("New Vegas Entrance");
        Room newVegas = new Room("New Vegas");

               
        // 2) --- Create Containers ---
        
        //   Footlocker
        ContainerThing foot_locker = new ContainerThing("footlocker", "small shiny footlocker", Mass.MEDIUM);
        foot_locker.setOpenable(true);
        foot_locker.setOpen(false);
        foot_locker.addAdjectives(new String[]{"shiny", "footlocker"});
        
        // Drawer
        ContainerThing drawer = new ContainerThing("slot", "small drawer", Mass.TINY, false, false, false, true);
        drawer.addAdjectives(new String[]{"small"});
        drawer.setOpenable(true);
        drawer.setShow(true);

        //  Garbage Bin
        ContainerThing garbage_bin = new ContainerThing("bin", "dirty garbage bin", Mass.MEDIUM);
        garbage_bin.setOpenable(true);
        garbage_bin.setOpen(false);
        garbage_bin.setShow(true);
        garbage_bin.addAdjectives(new String[]{"dirty", "garbage"});

        //  Vending Machine
        ContainerThing vending_machine = new ContainerThing("vending machine", "rusty vending machine", Mass.HUGE);
        vending_machine.setOpenable(true);
        vending_machine.setOpen(false);
        vending_machine.addAdjectives(new String[]{"huge", "rusty"});
        vending_machine.setLongDescription("huge sunset sarsaparilla vending machine covered in rust");

        //   Safe (locked)
        LockableThing safe = new LockableThing("safe", "cupboard on the wall", Mass.BIG, false, false, true, false, true);
        safe.setShow(false);

        // Cabinet
        ContainerThing cabinet = new ContainerThing("cabinet", "tall cabinet", Mass.HUGE);
        cabinet.setOpen(true);
        cabinet.setTakable(false);
        cabinet.addAdjectives(new String[]{"cabinet"});

        
        
        // 3) --- Create Game Things (and Generic Things) --- 
        GameThing desk = new GameThing("desk", "wooden desk", Mass.BIG, false, false);
        desk.addAdjectives(new String[]{"wooden"});
        desk.setLongDescription("wooden desk.\n"
                + "There is a small drawer inside the desk");
        desk.setShow(false);

        GameThing console = new GameThing("console", "display console", Mass.MEDIUM, false, false);
        console.addAdjectives(new String[]{"display"});
        console.setLongDescription("display console built into the desk.\nIt is displaying this message:\n"
                + "Place the micro chip into slot to open the vault");
        console.setShow(false);

        GameThing goldKey = new GameThing("key", "gold key", Mass.TINY);
        goldKey.addAdjectives(new String[]{"small", "gold", "golden"});
        goldKey.setLongDescription("small, gold key");

        GameThing silverKey = new GameThing("key", "silver key", Mass.TINY);
        silverKey.setAdjectives(new ArrayList<>(Arrays.asList("small", "silver")));
        silverKey.setLongDescription("small, silver key");

        GameThing microChip = new GameThing("chip", "micro chip", Mass.TINY);
        microChip.addAdjectives(new String[]{"micro", "mini", "tiny"});
        microChip.setTakable(true);
        microChip.setShow(true);


        // GenericThings (scenery objects - not intended to be 'used' or taken)
        GenericThing canyon = new GenericThing("canyon", "giant canyon with an endless river cutting through it", false);
        GenericThing barracks = new GenericThing("barracks", "huge spiky plants", true);
        GenericThing legionaries = new GenericThing("legionaries", "big army of legionaries", true);
        GenericThing villagers = new GenericThing("villagers","villagers be villaging", true);

        legionaries.addAdjectives(new String[]{"big", "army"});
        barracks.addAdjectives(new String[]{"old", "military"});
        canyon.addAdjectives(new String[]{"giant","endless"});
        villagers.addAdjectives(new String[]{"idk"});

        
        
        // 4) --- Add Things to Containers (that is, put them "into" Containers)
        foot_locker.addThing(silverKey);
        safe.addThing(goldKey);
        garbage_bin.addThing(silverKey);
        vending_machine.addThing(microChip);
        drawer.addThing(desk);
        
        
        // 5) --- Add objects to Rooms         //FIXXXXX              
        goodsprings.addThing(garbage_bin);
        mojaveOutpost.addThing(barracks);
        novac.addThing(barracks);
        redRockCanyon.addThing(canyon);

        // 6) Set any 'special' attributes
        safe.canBeUnlockedWith(goldKey);

        // 7) Optional but recommended - add all game objects to things
        // --- add all things to HashMap (for debugging)
        things = new HashMap<>();
        things.put("footLocker", foot_locker);
        things.put("garbageBin", garbage_bin);
        things.put("cabinet", cabinet);
        things.put("safe", safe);
        things.put("microChip", microChip);
        things.put("goldKey", goldKey);
        things.put("legionaries", legionaries);
        things.put("silverKey", silverKey);
        things.put("canyon", canyon);
        things.put("vendingMachine", vending_machine);
        things.put("desk", desk);
        things.put("console", console);
        things.put("drawer", drawer);

        // 8) Initialize rooms (including adding others room objects as 'exits'
        // and adding the pre-created lists (which may contain objects or may be empty)
        //           N,        S,           W,         E,       [Up],      [Down])
        // Goodsprings
        goodsprings.init("a small town west of the mojave.",
                mojaveDesert, Dir.NOEXIT, mojaveOutpost, Dir.NOEXIT);
        // Mojave Outpost
        mojaveOutpost.init("a military hub for all NCR operations in the southwestern Mojave. A huge viewscreen dominates one wall",
                primm, rangerStationCharlie, Dir.NOEXIT, goodsprings, Dir.NOEXIT, Dir.NOEXIT);
        mojaveOutpost.setLongDescription("an ultra-modern starship bridge.\n" +   
                "A huge viewscreen dominating one wall shows space in this quadrant.\n"
                + "There is a console on a desk with a slot beneath it");
        //Ranger Station Charlie
        rangerStationCharlie.init("A big station",
                mojaveDesert, Dir.NOEXIT, mojaveOutpost, Dir.NOEXIT);
        // Primm
        primm.init("typical boring-looking meeting room",
                redRockCanyon, mojaveOutpost, Dir.NOEXIT, Dir.NOEXIT, Dir.NOEXIT, Dir.NOEXIT
        );
        // Red Rock Canyon
        redRockCanyon.init("big, clanky, oily room full of strange, chugging machinery",
                fiends, primm, Dir.NOEXIT, Dir.NOEXIT, Dir.NOEXIT, Dir.NOEXIT
        );
        // Fiends
        fiends.init("long corridor with doors to the left and right and a stairway leading down",
                Dir.NOEXIT, redRockCanyon, Dir.NOEXIT, Dir.NOEXIT, Dir.NOEXIT, Dir.NOEXIT
        );
        // Mojave Desert
        mojaveDesert.init("dark room at the bottom of the ship",
                campMcCarran, rangerStationCharlie, goodsprings, novac, Dir.NOEXIT, Dir.NOEXIT
        );
        // Novac
        novac.init("big, empty room",
                Dir.NOEXIT, mojaveDesert, campMcCarran, boulderBeach
        );
        // Boulder Beach
        boulderBeach.init("room full of tables and chairs",
                novac, caesarsLegion, Dir.NOEXIT, Dir.NOEXIT
        );
        // Caesars Legion
        caesarsLegion.init("steamy hydroponics area with plants everywhere",
                boulderBeach, Dir.NOEXIT, Dir.NOEXIT, Dir.NOEXIT
        );
        // Camp McCarran
        campMcCarran.init("steamy hydroponics area with plants everywhere",
                newVegasEntrance, mojaveDesert, Dir.NOEXIT, novac
        );
        // New Vegas Entrance
        newVegasEntrance.init("steamy hydroponics area with plants everywhere",
                newVegas, campMcCarran, Dir.NOEXIT, Dir.NOEXIT
        );
        // New Vegas
        newVegas.init("huge glass structure filled with plants.\nThe air is hot and steamy.\nYou hear the sound of birds",
                Dir.NOEXIT, newVegasEntrance, Dir.NOEXIT, Dir.NOEXIT
        );

        // 9) Optional but recommended - add Rooms to map
        // create list of rooms (for debugging)
        map = new ArrayList<>();
        map.add(mojaveDesert);
        map.add(primm);
        map.add(novac);
        map.add(boulderBeach);
        map.add(mojaveOutpost);
        map.add(caesarsLegion);
        map.add(fiends);
        map.add(rangerStationCharlie);
        map.add(newVegas);
        map.add(newVegasEntrance);
        map.add(redRockCanyon);
        map.add(goodsprings);
        map.add(campMcCarran);

        // 10) create player and set location
        player = new Actor("player", "loveable game-player", goodsprings);

        // 11) call method to define introductory text to show when game starts
        defineIntroText();
    }

    // Intro - add any text to be shown when game starts
    private static void defineIntroText() {
        introtext = "a Nuclear Fallout has destroyed the world, only a few people managed to survive by hiding in vaults. \n"
                + "Decades after the apocalypse the world has turned into a never ending ruin covered in sand\n"
                + "The people who survived have formed factions and crime is ruling all of the mojave \n"
                + "You are a courier that was given the task to deliver a mysterious item to the city of New Vegas  \n\n"
                + "You are currently wandering the Mojave Desert and you find an abandoned caravan, you notice a chest \n"
                + "What do you want to do?\n"
                + "(Enter q to quit)";
    }

    public static String introText() {
        return introtext;
    }
}
