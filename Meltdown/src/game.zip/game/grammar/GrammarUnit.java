package game.grammar;

public class GrammarUnit implements java.io.Serializable {

    private String word;

    public GrammarUnit(String aWord) {
        word = aWord;
    }

    public String getWord() {
        return word;
    }

}
