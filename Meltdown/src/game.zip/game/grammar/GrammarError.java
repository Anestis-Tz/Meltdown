package game.grammar;

public class GrammarError extends GrammarUnit implements java.io.Serializable {

    // Flags errors when parsing input
    public GrammarError(String aWord) {
        super(aWord);
    }
}
