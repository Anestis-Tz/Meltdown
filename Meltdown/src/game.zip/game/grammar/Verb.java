package game.grammar;

public class Verb extends GrammarUnit implements java.io.Serializable {

    public Verb(String aWord) {
        super(aWord);
    }

}
