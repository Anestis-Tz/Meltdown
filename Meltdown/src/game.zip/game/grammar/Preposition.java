package game.grammar;

public class Preposition extends GrammarUnit implements java.io.Serializable {

    public Preposition(String aWord) {
        super(aWord);
    }

}
